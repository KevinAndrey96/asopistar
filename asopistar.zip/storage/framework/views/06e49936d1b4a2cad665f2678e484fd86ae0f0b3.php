<h1><?php echo e($modo); ?> registro de alimentación </h1>

<?php if(count($errors)>0): ?>

    <div class="alert alert-danger" role="alert">
        <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li> <?php echo e($error); ?> </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>    

<?php endif; ?>

<?php if($modo=="Crear"): ?>
<div class="form-group">
    <input type="hidden" class="form-control" name="pond_id" value="<?php echo e($pond_id); ?>" id="pond_id" readonly="readonly">
</div>
<?php endif; ?>

<div class="form-group">
    <label for="amount"> Cantidad Kg</label>
    <input type="number" class="form-control" name="amount" value="<?php echo e(isset($feeding->amount)?$feeding->amount:old('amount')); ?>" id="amount" step="0.01" min="1.0" placeholder="Cantidad">
</div>

<div>
    <label for="mark"> Marca </label>
    <select id="mark" name="mark" class="form-select" aria-label="Default select example">
        <?php $__currentLoopData = $foodbrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foodbrand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($foodbrand->id); ?>" > <?php echo e($foodbrand->name); ?> (<?php echo e($foodbrand->protein); ?>%)</option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
    <label for="date_of_entry"> Fecha </label>
    <input type="date" class="form-control" name="date_of_entry" value="<?php echo e(isset($feeding->date_of_entry)?$feeding->date_of_entry:old('date_of_entry')); ?>" id="date_of_entry" placeholder="aa/mm/dd">
</div>
<br>
<input class="btn btn-success" type="submit" value="<?php echo e($modo); ?> datos">

<a class="btn btn-primary" href="<?php echo e(url('/feeding/'.$pond_id)); ?>"> Regresar</a>
<?php /**PATH C:\xampp\htdocs\asopistar\resources\views/feeding/form.blade.php ENDPATH**/ ?>