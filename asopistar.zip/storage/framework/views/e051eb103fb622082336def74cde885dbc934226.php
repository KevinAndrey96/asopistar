<h1><?php echo e($modo); ?> Marca de Alimentos </h1>

<?php if(count($errors)>0): ?>

    <div class="alert alert-danger" role="alert">
        <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li> <?php echo e($error); ?> </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>    

<?php endif; ?>

<div class="form-group">
    <label for="name"> Marca </label>
    <input type="text" class="form-control" name="name" value="<?php echo e(isset($foodbrand->name)?$foodbrand->name:old('name')); ?>" id="name" placeholder="Marca">
</div>

<div class="form-group">
    <label for="protein"> Proteína %</label>
    <input type="number" class="form-control" name="protein" value="<?php echo e(isset($foodbrand->protein)?$foodbrand->protein:old('protein')); ?>" id="protein" step="0.01" min = "1.0" placeholder="1.0">
</div>

<br>
<input class="btn btn-success" type="submit" value="<?php echo e($modo); ?> datos">

<a class="btn btn-primary" href="<?php echo e(url('/foodbrand')); ?>"> Regresar</a>
<?php /**PATH C:\xampp\htdocs\asopistar\resources\views/foodbrand/form.blade.php ENDPATH**/ ?>