<h1><?php echo e($modo); ?> Usuario </h1>

<?php if(count($errors)>0): ?>

    <div class="alert alert-danger" role="alert">
        <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li> <?php echo e($error); ?> </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>    

<?php endif; ?>

<div class="form-group">
    <label for="name"> Nombres </label>
    <input type="text" class="form-control" name="name" value="<?php echo e(isset($user->name)?$user->name:old('name')); ?>" id="name" placeholder="Nombres">
</div>

<div class="form-group">
    <label for="lastname"> Apellidos </label>
    <input type="text" class="form-control" name="lastname" value="<?php echo e(isset($user->lastname)?$user->lastname:old('lastname')); ?>" id="lastname" placeholder="Apellidos">
</div>

<div class="form-group">
    <label for="email"> Correo </label>
    <input type="text" class="form-control" name="email" value="<?php echo e(isset($user->email)?$user->email:old('email')); ?>" id="email" placeholder="Correo">
</div>

<?php if($modo=="Crear"): ?>
<div class="password">
    <label for="password" > Contraseña </label>
    <input type="password" class="form-control" name="password" value="<?php echo e(isset($user->password)?$user->password:old('password')); ?>" id="password" required autocomplete="new-password" placeholder="Nueva contraseña">
</div>
<?php endif; ?>

<?php if($modo=="Crear"): ?> 
    <div class="form-group">
        <label for="unit_number"> # Unidad </label>
        <input type="text" class="form-control" name="unit_number" value="<?php echo e(isset($user->unit_number)?$user->unit_number:old('unit_number')); ?>" id="unit_number" placeholder="Código Productor">
    </div>
<?php endif; ?>

<?php if($modo=="Editar"): ?> 
    <?php if($user->rol == 'piscicultor'): ?> 
    <div class="form-group">
        <label for="unit_number"> # Unidad </label>
        <input type="text" class="form-control" name="unit_number" value="<?php echo e(isset($user->unit_number)?$user->unit_number:old('unit_number')); ?>" id="unit_number" placeholder="Código Productor">
    </div>
    <?php endif; ?>
<?php endif; ?>


<div class="form-group">
    <label for="code"> Cédula </label>
    <input type="text" class="form-control" name="code" value="<?php echo e(isset($user->code)?$user->code:old('code')); ?>" id="code" placeholder="Cedula">
</div>

<?php if($modo=="Crear"): ?> 
<div>
    <label for="gender"> Genero </label>
    <select id="gender" name="gender" class="form-select" aria-label="Default select example">
        <option value="masculino"  <?php echo e(old('gender') == 'masculino' ? 'selected' : ''); ?>>
            Masculino
        </option>
        <option value="femenino" <?php echo e(old('gender') == 'femenino' ? 'selected' : ''); ?>>
            Femenino
        </option>
    </select>
</div><!--//col-6-->
<?php endif; ?>

<?php if($modo=="Crear"): ?> 
    <div class="form-group">
        <label for="estate"> Predio </label>
        <input type="text" class="form-control" name="estate" value="<?php echo e(isset($user->estate)?$user->estate:old('estate')); ?>" id="estate" placeholder="Predio">
    </div>

    <div class="form-group">
        <label for="sidewalk"> Vereda </label>
        <input type="text" class="form-control" name="sidewalk" value="<?php echo e(isset($user->sidewalk)?$user->sidewalk:old('sidewalk')); ?>" id="sidewalk" placeholder="Vereda">
    </div>
<?php endif; ?>

<?php if($modo=="Editar"): ?> 
    <?php if($user->rol == 'piscicultor'): ?>
        <div class="form-group">
            <label for="estate"> Predio </label>
            <input type="text" class="form-control" name="estate" value="<?php echo e(isset($user->estate)?$user->estate:old('estate')); ?>" id="estate" placeholder="Predio">
        </div>

        <div class="form-group">
            <label for="sidewalk"> Vereda </label>
            <input type="text" class="form-control" name="sidewalk" value="<?php echo e(isset($user->sidewalk)?$user->sidewalk:old('sidewalk')); ?>" id="sidewalk" placeholder="Vereda">
        </div>
    <?php endif; ?>
<?php endif; ?>

<div class="form-group">
    <label for="phone"> Telefono</label>
    <input type="number" class="form-control" name="phone" value="<?php echo e(isset($user->phone)?$user->phone:old('phone')); ?>" id="phone" min="1" placeholder="3000000000">
</div>

<?php if($modo=="Crear"): ?>
<div>
    <label for="rol"> Rol </label>
    <select id="rol" name="rol" class="form-select" aria-label="Default select example">
        <option value="piscicultor"  <?php echo e(old('rol') == 'piscicultor' ? 'selected' : ''); ?>>
            Piscicultor
        </option>
        <option value="administrador" <?php echo e(old('rol') == 'administrador' ? 'selected' : ''); ?>>
            Administrador
        </option>
    </select>
</div><!--//col-6-->
<?php endif; ?>
<div class="form-group">
    <input type="hidden" class="form-control" name="updatepass" value="0" id="updatepass" readonly="readonly">
</div>
<br>
<input class="btn btn-success" type="submit" value="<?php echo e($modo); ?> datos">

<?php if(Auth::user()->rol == 'administrador'): ?> 
<a class="btn btn-primary" href="<?php echo e(url('/admin')); ?>"> Regresar</a>
<?php endif; ?>
<?php if(Auth::user()->rol == 'piscicultor'): ?>
<a class="btn btn-primary" href="<?php echo e(url('/home')); ?>"> Regresar</a>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\asopistar\resources\views/user/form.blade.php ENDPATH**/ ?>