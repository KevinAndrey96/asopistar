

<?php $__env->startSection('content'); ?>
<div class="container">
    
    <?php if(Session::has('mensaje')): ?>
        <div class="alert alert-warning alert-dismissible" role="alert">
            <?php echo e(Session::get('mensaje')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close" ></button>
        </div>
    <?php endif; ?>
        
    <?php if(Auth::user()->rol == 'administrador'): ?> 
    <h1>Alimentación</h1>
    <?php endif; ?>
    <?php if(Auth::user()->rol == 'piscicultor'): ?> 
    <a href="<?php echo e(url('feeding/create/'.$pond_id)); ?>" class="btn btn-success" > Registro de alimentación</a>
    <?php endif; ?>
    <br/>
    <br/>
    <table id= "my_table" class="table table-light">
        <thead class="thead-light">
            <tr>
                <th>Piscicultor</th>
                <th>Fecha</th>
                <th>Estanque</th>
                <th>Cantidad</th>
                <th>Etapa</th>
                <th>Edad</th>
                <th># Peces</th>
                <th>Peso Prom</th>
                <th>Marca</th>
                <th>Proteina</th>
                <?php if(Auth::user()->rol == 'piscicultor'): ?> 
                <th>Acciones</th>
                <?php endif; ?>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $feedings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feeding): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <!--<td><?php echo e($feeding->id); ?></td>-->
                <td>
                    <?php echo e($feeding->user->name); ?>

                </td>
                <td><?php echo e($feeding->date_of_entry); ?></td>
                <td>
                    <?php echo e($feeding->pond->id); ?>

                </td>
                <td><?php echo e($feeding->amount); ?>  Kg</td>
                <td><?php echo e($feeding->stage); ?></td>
                <td><?php echo e($feeding->age); ?> semanas</td>
                <td><?php echo e($feeding->number_of_fish); ?></td>
                <td><?php echo e($feeding->average_weight); ?>  gr</td>
                <td><?php echo e($feeding->mark); ?></td>
                <td><?php echo e($feeding->protein); ?> %</td>
                
                <?php if(Auth::user()->rol == 'piscicultor'): ?> 
                <td>
                <a href="<?php echo e(url('/feeding/'.$feeding->id.'/edit')); ?>" class="btn btn-warning">
                    Editar
                </a>
                    
                <form action="<?php echo e(url('/feeding/'.$feeding->id )); ?>" class="d-inline" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('DELETE')); ?>

                    <input class="btn btn-danger" type="submit" onclick="return confirm('¿Quieres borrar?')" 
                    value="Borrar">

                </form>

                </td>
                <?php endif; ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
    <script>
        $(document).ready( function () {
            $('#my_table').DataTable();
        } );
    </script>  
    <?php if(Auth::user()->rol == 'administrador'): ?> 
    <a class="btn btn-primary" href="<?php echo e(url('/user/'.$id )); ?>"> Regresar</a>
    <?php endif; ?>
    <?php if(Auth::user()->rol == 'piscicultor'): ?>
    <a class="btn btn-primary" href="<?php echo e(url('/pond')); ?>"> Regresar</a>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asopistar\resources\views/feeding/index.blade.php ENDPATH**/ ?>