<h1><?php echo e($modo); ?> Estanque </h1>

<?php if(count($errors)>0): ?>

    <div class="alert alert-danger" role="alert">
        <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li> <?php echo e($error); ?> </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>    

<?php endif; ?>

<div class="form-group">
    <label for="pondcode"> Código de Estanque </label>
    <input type="text" class="form-control" name="pondcode" value="<?php echo e(isset($pond->pondcode)?$pond->pondcode:old('pondcode')); ?>" id="pondcode" placeholder="Código">
</div>

<div class="form-group">
    <label for="pond_area"> Espejo de agua m<sup>2</sup></label>
    <input type="number" class="form-control" name="pond_area" value="<?php echo e(isset($pond->pond_area)?$pond->pond_area:old('pond_area')); ?>" id="pond_area" step="0.01" min = "1.0" placeholder="Área">
</div>

<div class="form-group">
    <label for="water"> Aforo de agua Lt/seg</label>
    <input type="number" class="form-control" name="water" value="<?php echo e(isset($pond->water)?$pond->water:old('water')); ?>" id="water" step="0.01" min = "1.0" placeholder="Aforo">
</div>

<?php if($modo=="Crear"): ?>
<div>
    <label for="tools"> Equipos </label>
    <select id="tools" name="tools" class="form-select" aria-label="Default select example">
        <option value="Ninguno"  <?php echo e(old('tools') == 'Ninguno' ? 'selected' : ''); ?>>
        Ninguno
        </option>
        <option value="Aireadores" <?php echo e(old('tools') == 'Aireadores' ? 'selected' : ''); ?>>
        Aireadores
        </option>
    </select>
</div><!--//col-6-->
<?php else: ?>
    <?php if($pond->tools == "Ninguno"): ?>
    <div>
        <label for="tools"> Equipos </label>
        <select id="tools" name="tools" class="form-select" aria-label="Default select example">
            <option value="Ninguno"  <?php echo e(old('tools') == 'Ninguno' ? 'selected' : ''); ?>>
            Ninguno
            </option>
            <option value="Aireadores" <?php echo e(old('tools') == 'Aireadores' ? 'selected' : ''); ?>>
            Aireadores
            </option>
        </select>
    </div><!--//col-6-->
    <?php else: ?>
    <div>
        <label for="tools"> Equipos </label>
        <select id="tools" name="tools" class="form-select" aria-label="Default select example">
            <option value="Aireadores" <?php echo e(old('tools') == 'Aireadores' ? 'selected' : ''); ?>>
            Aireadores
            </option>
            <option value="Ninguno"  <?php echo e(old('tools') == 'Ninguno' ? 'selected' : ''); ?>>
            Ninguno
            </option>
        </select>
    </div><!--//col-6-->
    <?php endif; ?>
<?php endif; ?>

<br>
<input class="btn btn-success" type="submit" value="<?php echo e($modo); ?> datos">

<a class="btn btn-primary" href="<?php echo e(url('/pond')); ?>"> Regresar</a>
<?php /**PATH C:\xampp\htdocs\asopistar\resources\views/pond/form.blade.php ENDPATH**/ ?>