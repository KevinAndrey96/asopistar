<h1><?php echo e($modo); ?> Piscicultor </h1>

<?php if(count($errors)>0): ?>

    <div class="alert alert-danger" role="alert">
        <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li> <?php echo e($error); ?> </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>    

<?php endif; ?>

<div class="form-group">
    <label for="Nombres"> Nombre </label>
    <input type="text" class="form-control" name="Nombre" value="<?php echo e(isset($piscicultor->Nombre)?$piscicultor->Nombre:old('Nombre')); ?>" id="Nombre" placeholder="Nombre completo">
</div>

<div class="form-group">
    <label for="Email"> Correo </label>
    <input type="text" class="form-control" name="Email" value="<?php echo e(isset($piscicultor->Email)?$piscicultor->Email:old('Email')); ?>" id="Email" placeholder="Correo">
</div>

<div class="form-group">
    <label for="Codigo"> Codigo </label>
    <input type="text" class="form-control" name="Codigo" value="<?php echo e(isset($piscicultor->Codigo)?$piscicultor->Codigo:old('Codigo')); ?>" id="Codigo" placeholder="Código Productor">
</div>

<div class="form-group">
    <label for="Predio"> Predio </label>
    <input type="text" class="form-control" name="Predio" value="<?php echo e(isset($piscicultor->Predio)?$piscicultor->Predio:old('Predio')); ?>" id="Predio" placeholder="Predio">
</div>

<div class="form-group">
    <label for="Vereda"> Vereda </label>
    <input type="text" class="form-control" name="Vereda" value="<?php echo e(isset($piscicultor->Vereda)?$piscicultor->Vereda:old('Vereda')); ?>" id="Vereda" placeholder="Vereda">
</div>
<br>
<input class="btn btn-success" type="submit" value="<?php echo e($modo); ?> datos">

<a class="btn btn-primary" href="<?php echo e(url('/')); ?>"> Regresar</a>
<?php /**PATH C:\xampp\htdocs\asopistar\resources\views/piscicultor/form.blade.php ENDPATH**/ ?>