
<?php $__env->startSection('sidebarContent'); ?>
<li class="nav-item">
    <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
    <a class="nav-link" href="<?php echo e(url('/')); ?>">
        <span class="nav-icon">
            <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-house-door" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" d="M7.646 1.146a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 .146.354v7a.5.5 0 0 1-.5.5H9.5a.5.5 0 0 1-.5-.5v-4H7v4a.5.5 0 0 1-.5.5H2a.5.5 0 0 1-.5-.5v-7a.5.5 0 0 1 .146-.354l6-6zM2.5 7.707V14H6v-4a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v4h3.5V7.707L8 2.207l-5.5 5.5z"/>
                <path fill-rule="evenodd" d="M13 2.5V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z"/>
            </svg>
        </span>
        <span class="nav-link-text">Principal</span>
    </a><!--//nav-link-->
</li><!--//nav-item-->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    
    <?php if(Session::has('mensaje')): ?>
        <div class="alert alert-warning alert-dismissible" role="alert">
            <?php echo e(Session::get('mensaje')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close" ></button>
        </div>
    <?php endif; ?>
        
    <a href="<?php echo e(url('piscicultor/create')); ?>" class="btn btn-success" > Registrar nuevo piscicultor</a>
    <br/>
    <br/>
    <table class="table table-light">
        <thead class="thead-light">
            <tr>
                <th>Codigo</th>
                <th>Nombre</th>
                <th>Email</th>
                <th>Vereda</th>
                <th>Predio</th>
                <th>Acciones</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $piscicultors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $piscicultor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <!--<td><?php echo e($piscicultor->id); ?></td>-->
                <td><?php echo e($piscicultor->Codigo); ?></td>
                <td><?php echo e($piscicultor->Nombre); ?></td>
                <td><?php echo e($piscicultor->Email); ?></td>
                <td><?php echo e($piscicultor->Predio); ?></td>
                <td><?php echo e($piscicultor->Vereda); ?></td>
                <td>
                
                <a href="<?php echo e(url('/piscicultor/'.$piscicultor->id.'/edit')); ?>" class="btn btn-warning">
                    Editar
                </a>
                
                    
                <form action="<?php echo e(url('/piscicultor/'.$piscicultor->id )); ?>" class="d-inline" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('DELETE')); ?>

                    <input class="btn btn-danger" type="submit" onclick="return confirm('¿Quieres borrar?')" 
                    value="Borrar">

                </form>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
    <?php echo $piscicultors->links(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asopistar\resources\views/piscicultor/index.blade.php ENDPATH**/ ?>