

<?php $__env->startSection('content'); ?>
<div class="container">
    
    <?php if(Session::has('mensaje')): ?>
        <div class="alert alert-warning alert-dismissible" role="alert">
            <?php echo e(Session::get('mensaje')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close" ></button>
        </div>
    <?php endif; ?>
        
    <a href="<?php echo e(url('species/create')); ?>" class="btn btn-success" > Registro de Especies</a>
    <br/>
    <br/>
    <table id= "my_table" class="table table-light">
        <thead class="thead-light">
            <tr>
                <th>Especie</th>
                <th>Etapa Cria Final</th>
                <th>Etapa Levante Inicio</th>
                <th>Etapa Levante Final</th>
                <th>Etapa Cebo Inicio</th>
                <th>Acciones</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $species; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($specie->species); ?></td>
                <td><?php echo e($specie->young_end); ?> semanas</td>
                <td><?php echo e($specie->levante_start); ?> semanas</td>
                <td><?php echo e($specie->levante_end); ?> semanas</td>
                <td><?php echo e($specie->bait_start); ?> semanas</td>
                <td>
                
                <a href="<?php echo e(url('/species/'.$specie->id.'/edit')); ?>" class="btn btn-warning">
                    Editar
                </a>
                
                    
                <form action="<?php echo e(url('/species/'.$specie->id )); ?>" class="d-inline" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('DELETE')); ?>

                    <input class="btn btn-danger" type="submit" onclick="return confirm('¿Quieres borrar?')" 
                    value="Borrar">

                </form>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
    <script>
        $(document).ready( function () {
            $('#my_table').DataTable();
        } );
    </script>  
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asopistar\resources\views/species/index.blade.php ENDPATH**/ ?>