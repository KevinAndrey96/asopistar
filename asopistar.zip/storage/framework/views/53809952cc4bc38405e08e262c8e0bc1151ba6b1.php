<h1><?php echo e($modo); ?> Registro sanitario </h1>

<?php if(count($errors)>0): ?>

    <div class="alert alert-danger" role="alert">
        <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li> <?php echo e($error); ?> </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>    

<?php endif; ?>

<?php if($modo=="Crear"): ?>
<div class="form-group">
    <input type="hidden" class="form-control" name="pond_id" value="<?php echo e($pond_id); ?>" id="pond_id" readonly="readonly">
</div>
<?php endif; ?>

<div>
    <label for="agent"> Equipos </label>
    <select id="agent" name="agent" class="form-select" aria-label="Default select example">
        <option value="Hongos"  <?php echo e(old('agent') == 'Hongos' ? 'selected' : ''); ?>>
        Hongos
        </option>
        <option value="Bacterias"  <?php echo e(old('agent') == 'Bacterias' ? 'selected' : ''); ?>>
        Bacterias
        </option>
        <option value="Virus"  <?php echo e(old('agent') == 'Virus' ? 'selected' : ''); ?>>
        Virus
        </option>
        <option value="Parasitos"  <?php echo e(old('agent') == 'Parasitos' ? 'selected' : ''); ?>>
        Parasitos
        </option>
        <option value="Contaminación"  <?php echo e(old('agent') == 'Contaminación' ? 'selected' : ''); ?>>
        Contaminación
        </option>
    </select>
</div>

<div class="form-group">
    <label for="description"> Sintomatologia </label>
    <input type="text" class="form-control" name="description" value="<?php echo e(isset($sanitary->description)?$sanitary->description:old('description')); ?>" id="description" >
</div>

<br>
<input class="btn btn-success" type="submit" value="<?php echo e($modo); ?> datos">

<a class="btn btn-primary" href="<?php echo e(url('/sanitary/'.$pond_id)); ?>"> Regresar</a>
<?php /**PATH C:\xampp\htdocs\asopistar\resources\views/sanitary/form.blade.php ENDPATH**/ ?>