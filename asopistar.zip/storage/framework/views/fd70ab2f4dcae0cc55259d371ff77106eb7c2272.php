<h1><?php echo e($modo); ?> Producto </h1>

<?php if(count($errors)>0): ?>

    <div class="alert alert-danger" role="alert">
        <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li> <?php echo e($error); ?> </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>    

<?php endif; ?>

<div class="form-group">
    <label for="name"> Nombre</label>
    <input type="text" class="form-control" name="name" value="<?php echo e(isset($product->name)?$product->name:old('name')); ?>" id="name" placeholder="Nombre">
</div>

<div class="form-group">
    <label for="description"> Descripción </label>
    <input type="text" class="form-control" name="description" value="<?php echo e(isset($product->description)?$product->description:old('description')); ?>" id="description" placeholder="Descripción">
</div>

<div class="form-group">
    <label for="price"> Precio </label>
    <input type="number" class="form-control" name="price" value="<?php echo e(isset($product->price)?$product->price:old('price')); ?>" id="price" min="1" placeholder="1">
</div>

<div class="form-group">
    <label for="image"> Imagen </label>
    <?php if(isset($product->image_url)): ?>
    </br>
    <img class="img-thumbnail img-fluid" src="<?php echo e('https://portal.asopistar.com/'.$product->image_url); ?>" width="100" alt = "No carga">
    </br>
    <?php endif; ?>
    <input type="file" class="form-control" name="image" value="" id="image">
</div>

<br>
<input class="btn btn-success" type="submit" value="<?php echo e($modo); ?> datos">

<a class="btn btn-primary" href="<?php echo e(url('/product')); ?>"> Regresar</a>
<?php /**PATH C:\xampp\htdocs\asopistar\resources\views/product/form.blade.php ENDPATH**/ ?>