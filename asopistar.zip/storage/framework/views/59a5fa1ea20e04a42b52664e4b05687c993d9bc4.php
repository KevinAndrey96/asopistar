

<?php $__env->startSection('content'); ?>
<div class="container">
    
    <?php if(Session::has('mensaje')): ?>
        <div class="alert alert-warning alert-dismissible" role="alert">
            <?php echo e(Session::get('mensaje')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close" ></button>
        </div>
    <?php endif; ?>
       
    <?php if(Auth::user()->rol == 'administrador'): ?> 
    <h1>Siembra de Alevines</h1>
    <?php endif; ?>
    <?php if(Auth::user()->rol == 'piscicultor'): ?> 
    <a href="<?php echo e(url('alevin/create/'.$pond_id )); ?>" class="btn btn-success" > Registro de siembra de alevines</a>
    <?php endif; ?>
    <br/>
    <br/>
    <table id= "my_table" class="table table-light">
        <thead class="thead-light">
            <tr>
                <th>Piscicultor</th>
                <th>Ingreso</th>
                <th>Edad</th>
                <th>Estanque</th>
                <th># de Peces</th>
                <th>Especie</th>
                <th>Origen</th>
                <?php if(Auth::user()->rol == 'piscicultor'): ?> 
                <th>Acciones</th>
                <?php endif; ?>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $alevins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alevin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <!--<td><?php echo e($alevin->id); ?></td>-->
                <td>
                    <?php echo e($alevin->user->name); ?>

                </td>
                <td><?php echo e($alevin->date_of_entry); ?></td>
                <?php
                $fechaAntigua  = $alevin->date_of_entry;
                $fechaAntigua = Carbon\Carbon::createFromFormat('Y-m-d', $fechaAntigua);
                $fechaNueva  =  Carbon\Carbon::now();
                $cantidadDias = $fechaAntigua->diffInWeeks($fechaNueva);
                $age = $cantidadDias;

                $specie = $alevin->species;
                ?>
                <td><?php echo e($age); ?> semanas</td>
                <!--<td><?php echo e($alevin->pond_id); ?></td>-->
                <td><?php echo e($alevin->pond->id); ?></td>
                <td><?php echo e($alevin->amount); ?></td>
                <td><?php echo e($alevin->species); ?></td>
                <td><?php echo e($alevin->source); ?></td>

                <?php if(Auth::user()->rol == 'piscicultor'): ?> 
                <td>
                
                <a href="<?php echo e(url('/alevin/'.$alevin->id.'/edit')); ?>" class="btn btn-warning">
                    Editar
                </a>
                
                <form action="<?php echo e(url('/alevin/'.$alevin->id )); ?>" class="d-inline" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('DELETE')); ?>

                    <input class="btn btn-danger" type="submit" onclick="return confirm('¿Quieres borrar?')" 
                    value="Borrar">

                </form>

                </td>
                <?php endif; ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
    <script>
        $(document).ready( function () {
            $('#my_table').DataTable();
        } );
    </script>
    <br>
    <?php if(Auth::user()->rol == 'administrador'): ?> 
    <a class="btn btn-primary" href="<?php echo e(url('/user/'.$id )); ?>"> Regresar</a>
    <?php endif; ?>
    <?php if(Auth::user()->rol == 'piscicultor'): ?>
    <a class="btn btn-primary" href="<?php echo e(url('/pond')); ?>"> Regresar</a>
    <?php endif; ?>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asopistar\resources\views/alevin/index.blade.php ENDPATH**/ ?>