

<?php $__env->startSection('content'); ?>
<div class="container">
    
    <?php if(Session::has('mensaje')): ?>
        <div class="alert alert-warning alert-dismissible" role="alert">
            <?php echo e(Session::get('mensaje')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close" ></button>
        </div>
    <?php endif; ?>
        
    <a href="<?php echo e(url('provider/create')); ?>" class="btn btn-success" > Registro de Proveedores</a>
    <br/>
    <br/>
    <table id= "my_table" class="table table-light">
        <thead class="thead-light">
            <tr>
                <th>Nombre Empresa</th>
                <th>Nit</th>
                <th>Ciudad</th>
                <th>Telefono</th>
                <th>Representante</th>
                <th>Acciones</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($provider->name); ?></td>
                <td><?php echo e($provider->nit); ?></td>
                <td><?php echo e($provider->city); ?></td>
                <td><?php echo e($provider->phone); ?></td>
                <td><?php echo e($provider->representative); ?></td>
                <td>
                
                <a href="<?php echo e(url('/provider/'.$provider->id.'/edit')); ?>" class="btn btn-warning">
                    Editar
                </a>
                
                    
                <form action="<?php echo e(url('/provider/'.$provider->id )); ?>" class="d-inline" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('DELETE')); ?>

                    <input class="btn btn-danger" type="submit" onclick="return confirm('¿Quieres borrar?')" 
                    value="Borrar">

                </form>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
    <script>
        $(document).ready( function () {
            $('#my_table').DataTable();
        } );
    </script>  
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asopistar\resources\views/provider/index.blade.php ENDPATH**/ ?>