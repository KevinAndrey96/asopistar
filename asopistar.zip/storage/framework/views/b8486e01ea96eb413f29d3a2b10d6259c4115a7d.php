

<?php $__env->startSection('content'); ?>
<div class="container">

    <form action="<?php echo e(url('/alevin/'.$alevin->id)); ?>" method="post" enctype="multipart/form-data"> 
        <?php echo csrf_field(); ?>
        <?php echo e(method_field('PATCH')); ?>


        <?php echo $__env->make('alevin.form', ['modo'=>'Editar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asopistar\resources\views/alevin/edit.blade.php ENDPATH**/ ?>