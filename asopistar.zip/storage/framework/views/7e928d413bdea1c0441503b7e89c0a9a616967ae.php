

<?php $__env->startSection('content'); ?>

<div class="container">
    <?php if($isusers == 0): ?>
        <h1> Reporte </h1>
    <?php else: ?>
        <h1> Reporte Global</h1>
    <?php endif; ?>
    
    <br/>
    <table id= "my_table" class="table table-light">
        <thead class="thead-light">
            <tr>
                <th>Nombre</th>
                <th>Genero</th>
                <th>Estanques</th>
                <th>Comida Semana Actual</th>
                <th>Estanques </th>
                <th># Peces</th>
                <th>Especies</th>
                <th>Estanques Cosecha</th>
                <th>Cosecha Aproximada</th>
                <th>Reportes sanitarios</th>
            </tr>
        </thead>

        <tbody>           
            <?php if($isusers == 0): ?>
            <tr>
                
                <td><?php echo e($user->name.' '.$user->lastname); ?></td>
                <td><?php echo e($user->gender); ?></td>
                <td>
                    <?php echo e('Activos   '.$user->activeponds); ?>

                </br>
                    <?php echo e('Inactivos '.$user->inactiveponds); ?>

                </td>
                <td><?php echo e($user->foodcount); ?> kg</td>
                <td>
                    Cria: <?php echo e($user->youngcount); ?>

                    </br>
                    levante: <?php echo e($user->levantecount); ?>

                    </br>
                    Cebo: <?php echo e($user->baitcount); ?>

                </td>
                <td><?php echo e($user->fishcount); ?></td>
                <td>
                    <?php if($user->speciecount == 0): ?>
                        N/A
                    <?php else: ?>
                        <?php $__currentLoopData = $user->userSpecies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($specie); ?>.
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </td>
                <td><?php echo e($user->harvestcount); ?></td>
                <td>
                    1 Mes <?php echo e($user->week4weight); ?> Kg
                    </br>
                    3 Mes <?php echo e($user->week12weight); ?> Kg
                    </br>
                    6 Mes <?php echo e($user->week24weight); ?> Kg
                </td>
                <td><?php echo e($user->sanitarycount); ?></td>
                
            </tr>
            <?php else: ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    
                    <td><?php echo e($user->name.' '.$user->lastname); ?></td>
                    <td><?php echo e($user->gender); ?></td>
                    <td>
                        <?php echo e('Activos   '.$user->activeponds); ?>

                    </br>
                        <?php echo e('Inactivos '.$user->inactiveponds); ?>

                    </td>
                    <td><?php echo e($user->foodcount); ?> kg</td>
                    <td>
                    Cria: <?php echo e($user->youngcount); ?>

                    </br>
                    levante: <?php echo e($user->levantecount); ?>

                    </br>
                    Cebo: <?php echo e($user->baitcount); ?>

                    </td>
                    <td><?php echo e($user->fishcount); ?></td>
                    <td>
                        <?php if($user->speciecount == 0): ?>
                            N/A
                        <?php else: ?>
                            <?php $__currentLoopData = $user->userSpecies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($specie); ?>.
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($user->harvestcount); ?></td>
                    <td>
                        1 Mes <?php echo e($user->week4weight); ?> Kg
                        </br>
                        3 Mes <?php echo e($user->week12weight); ?> Kg
                        </br>
                        6 Mes <?php echo e($user->week24weight); ?> Kg
                    </td>
                    <td><?php echo e($user->sanitarycount); ?></td>
                    
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

        <tbody>
            <tr>
                <td>Total</td>
                <td>
                    <?php echo e('# F: '.$total['femalecount']); ?>

                    </br>
                    <?php echo e('# M: '.$total['malecount']); ?>

                </td>
                <td>
                    <?php echo e('Activos   '.$total['activeponds']); ?>

                    </br>
                    <?php echo e('Inactivos '.$total['inactiveponds']); ?>

                </td>
                
                <td><?php echo e($total['foodcount']); ?> kg</td>
                <td>
                Cria: <?php echo e($total['youngcount']); ?>

                </br>
                levante: <?php echo e($total['levantecount']); ?>

                </br>
                Cebo: <?php echo e($total['baitcount']); ?>

                </td>
                <td><?php echo e($total['fishcount']); ?></td>
                <td>
                    <?php $__currentLoopData = $total['species']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($specie); ?>.
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td><?php echo e($total['harvestcount']); ?></td>
                <td>
                    1 Mes <?php echo e($total['week4weight']); ?> Kg
                    </br>
                    3 Mes <?php echo e($total['week12weight']); ?> Kg
                    </br>
                    6 Mes <?php echo e($total['week24weight']); ?> Kg
                </td>
                <td><?php echo e($total['sanitarycount']); ?></td>
            </tr>
            <?php endif; ?>  
        </tbody>
    </table>
    <script>
        $(document).ready( function () {
            $('#my_table').DataTable({
				"language": {
      				"url": "//cdn.datatables.net/plug-ins/1.10.15/i18n/Spanish.json"
				}});
        } );
    </script>
    <br>
    <?php if($isusers == 0): ?>
    <a class="btn btn-primary" href="<?php echo e(url('/user/'.$id )); ?>"> Regresar</a>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asopistar\resources\views/user/userreport.blade.php ENDPATH**/ ?>