<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
	<title> <?php echo e($user->title); ?> </title>

</head>
<p style="line-height: 100%; margin-top: 0.17in; margin-bottom: 0.17in">
<font size="4" style="font-size: 14pt"><b> <?php echo e($user->title); ?> </b></font></p>

<body lang="es-ES" link="#000080" vlink="#800000" dir="ltr"><p style="line-height: 100%; margin-top: 0.17in; margin-bottom: 0.17in">
<font size="3" style="font-size: 12pt"><b>Usuario:</b></font><font size="3" style="font-size: 12pt">
                         	<?php echo e($user->name.' '.$user->lastname); ?></font></p>
<p style="line-height: 100%; margin-top: 0.17in; margin-bottom: 0.17in">
<font size="3" style="font-size: 12pt"><b>Cédula:</b></font><font size="3" style="font-size: 12pt">
    	<?php echo e($user->code); ?></font></p>
<p style="line-height: 100%; margin-top: 0.17in; margin-bottom: 0.17in">
<font size="3" style="font-size: 12pt"><b>Genero:</b></font><font size="3" style="font-size: 12pt">
    	<?php echo e($user->gender); ?></font></p>
<p style="line-height: 100%; margin-top: 0.17in; margin-bottom: 0.17in">
<font size="3" style="font-size: 12pt"><b>Fecha del reporte:</b></font><font size="3" style="font-size: 12pt">
    	<?php echo e($user->date); ?></font></p>
<p style="line-height: 100%; margin-top: 0.17in; margin-bottom: 0.17in">

</p>
<p style="line-height: 100%; margin-top: 0.17in; margin-bottom: 0.17in">
<font size="4" style="font-size: 14pt"><b>Estanque</b></font></p>

<table class="table table-light" border="1">
	<thead class="thead-light">
		<tr>
			<th># de Estanque</th>
			<th>Área de Estanque</th>
			<th>Aforo de agua</th>
			<th>Equipos</th>
			<th>Edad</th>
			<th>Etapa</th>

		</tr>
	</thead>

	<tbody>
		<?php $__currentLoopData = $ponds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($pond->pondcode); ?></td>
			<td><?php echo e($pond->pond_area); ?> Km2</td>
			<td><?php echo e($pond->water); ?> lt/min</td>
			<td><?php echo e($pond->tools); ?></td>
			<td><?php echo e($pond->age); ?> semanas</td>
			<td><?php echo e($pond->stage); ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</tbody>
</table>
<?php if($pond->alevinExist == '0'): ?>
<p style="line-height: 100%; margin-top: 0.17in; margin-bottom: 0.17in">
<font size="4" style="font-size: 14pt"><b>No hay alevines</b></font></p>
<?php endif; ?>
<?php if($pond->alevinExist == '1'): ?>
<p style="line-height: 100%; margin-top: 0.17in; margin-bottom: 0.17in">
<font size="4" style="font-size: 14pt"><b>Alevines</b></font></p>

<table class="table table-light" border="1">
	<thead class="thead-light">
		<tr>
			<th>Ingreso</th>
			<th># de Peces</th>
			<th>Especie</th>
			<th>Origen</th>
		</tr>
	</thead>

	<tbody>
		<tr>
			<td><?php echo e($alevin->date_of_entry); ?></td>
			<td><?php echo e($alevin->amount); ?></td>
			<td><?php echo e($alevin->species); ?></td>
			<td><?php echo e($alevin->source); ?></td>
		</tr>

	</tbody>
</table>

<p style="line-height: 100%; margin-top: 0.17in; margin-bottom: 0.17in">
<font size="4" style="font-size: 14pt"><b><?php echo e('Alimentación, Total: '.$user->foodcount.' kg'); ?></b></font></p>

<table class="table table-light" border="1">
	<thead class="thead-light">
		<tr>
			<th>Fecha Registro</th>
			<th>Cantidad de alimento</th>
			<th>Etapa</th>
			<th>Edad</th>
			<th>Peso Promedio</th>
			<th>Marca</th>
			<th>Proteina</th>
		</tr>
	</thead>

	<tbody>
		<?php $__currentLoopData = $feedings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feeding): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($feeding->date_of_entry); ?></td>
			<td><?php echo e($feeding->amount); ?>  Kg</td>
			<td><?php echo e($feeding->stage); ?></td>
			<td><?php echo e($feeding->age); ?> semanas</td>
			<td><?php echo e($feeding->average_weight); ?>  gr</td>
			<td><?php echo e($feeding->mark); ?></td>
			<td><?php echo e($feeding->protein); ?> %</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>

<p style="line-height: 100%; margin-top: 0.17in; margin-bottom: 0.17in">
<font size="4" style="font-size: 14pt"><b>
	<?php echo e('Hielo, Total Sacrificio: '.$user->iceSacrificecount.' kg, Enfriado: '.$user->iceCooledcount.' kg, Transporte: '.$user->iceTransportcount.' kg'); ?>

</b></font></p>

<table class="table table-light" border="1">
	<thead class="thead-light">
		<tr>
			<th>Fecha Registro</th>
			<th>Pesca</th>
			<th>Cantidad sacrificio</th>
			<th>Cantidad enfriado</th>
			<th>Cantidad transporte</th>
		</tr>
	</thead>

	<tbody>
		<?php $__currentLoopData = $ices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($ice->date_of_entry); ?></td>
			<td><?php echo e($ice->fishing_amount); ?> Ton</td>
			<td><?php echo e($ice->sacrifice_amount); ?> kg</td>
			<td><?php echo e($ice->cooled_amount); ?> kg</td>
			<td><?php echo e($ice->transport_amount); ?> kg</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</tbody>
</table>

<p style="line-height: 100%; margin-top: 0.17in; margin-bottom: 0.17in">
<font size="4" style="font-size: 14pt"><b>Cosecha</b></font></p>

<table class="table table-light" border="1">
	<thead class="thead-light">
		<tr>
			<th>Fecha</th>
			<th>Cantidad</th>
			<th># de peces</th>
			<th>Peso prom</th>
			<th>Destino</th>
		</tr>
	</thead>

	<tbody>
		<?php $__currentLoopData = $harvests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $harvest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($harvest->date_of_entry); ?></td>
			<td><?php echo e($harvest->amount); ?> Ton</td>
			<td><?php echo e($harvest->fish_number); ?></td>
			<td><?php echo e($harvest->average_weight); ?> gr</td>
			<td><?php echo e($harvest->destination); ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</tbody>
</table>

<p style="line-height: 100%; margin-top: 0.17in; margin-bottom: 0.17in">
<font size="4" style="font-size: 14pt"><b>Pesos</b></font></p>

<table class="table table-light" border="1">
	<thead class="thead-light">
		<tr>
			<th>Muestreo</th>
			<th>Peso Total</th>
			<th># de Peces</th>
			<th>Peso Prom</th>
		</tr>
	</thead>

	<tbody>
		<?php $__currentLoopData = $weights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($weight->agent); ?></td>
			<td><?php echo e($weight->total_weight); ?> kg</td>
			<td><?php echo e($weight->fish_number); ?></td>
			<td><?php echo e($weight->average_weight); ?> gr</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</tbody>
</table>

<p style="line-height: 100%; margin-top: 0.17in; margin-bottom: 0.17in">
<font size="4" style="font-size: 14pt"><b>Registros Sanitarios</b></font></p>

<table class="table table-light" border="1">
	<thead class="thead-light">
		<tr>
			<th>Agente</th>
			<th>Descripcion</th>
		</tr>
	</thead>

	<tbody>
		<?php $__currentLoopData = $sanitaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sanitary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($sanitary->agent); ?></td>
			<td><?php echo e($sanitary->description); ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</tbody>
</table>
<?php endif; ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\asopistar\resources\views/pond/report.blade.php ENDPATH**/ ?>