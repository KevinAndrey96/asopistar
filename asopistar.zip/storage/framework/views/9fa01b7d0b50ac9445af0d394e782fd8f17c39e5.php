<h1><?php echo e($modo); ?> Pesajes </h1>

<?php if(count($errors)>0): ?>

    <div class="alert alert-danger" role="alert">
        <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li> <?php echo e($error); ?> </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>    

<?php endif; ?>

<?php if($modo=="Crear"): ?>
<div class="form-group">
    <input type="hidden" class="form-control" name="pond_id" value="<?php echo e($pond_id); ?>" id="pond_id" readonly="readonly">
</div>
<?php endif; ?>

<div>
    <label for="agent"> Tipo de Muestreo </label>
    <select id="agent" name="agent" class="form-select" aria-label="Default select example">
        <option value="Control de Pesaje"  <?php echo e(old('agent') == "Control_de_Pesaje" ? 'selected' : ''); ?>>
        Control de Pesaje
        </option>
        <option value="Control de Crecimiento"  <?php echo e(old('agent') == 'Control_de_Crecimiento' ? 'selected' : ''); ?>>
        Control de Crecimiento
        </option>
        <option value="Ajuste de Dieta"  <?php echo e(old('agent') == 'Ajuste_de_Dieta' ? 'selected' : ''); ?>>
        Ajuste de Dieta
        </option>
    </select>
</div><!--//col-6-->

<div class="form-group">
    <label for="total_weight"> Peso Total Kg</label>
    <input type="number" class="form-control" name="total_weight" value="<?php echo e(isset($weight->total_weight)?$weight->total_weight:old('total_weight')); ?>" id="total_weight" step="0.01" min = "1.0" placeholder="Peso Total">
</div>

<div class="form-group">
    <label for="fish_number"> Numero de peces</label>
    <input type="number" class="form-control" name="fish_number" value="<?php echo e(isset($weight->fish_number)?$weight->fish_number:old('fish_number')); ?>" id="fish_number" min = "1" placeholder="# de peces">
</div>

<br>
<input class="btn btn-success" type="submit" value="<?php echo e($modo); ?> datos">

<a class="btn btn-primary" href="<?php echo e(url('/weight/'.$pond_id)); ?>"> Regresar</a>
<?php /**PATH C:\xampp\htdocs\asopistar\resources\views/weight/form.blade.php ENDPATH**/ ?>