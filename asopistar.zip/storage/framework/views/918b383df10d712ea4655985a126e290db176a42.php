

<?php $__env->startSection('content'); ?>
<div class="container">
    
    <?php if(Session::has('mensaje')): ?>
        <div class="alert alert-warning alert-dismissible" role="alert">
            <?php echo e(Session::get('mensaje')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close" ></button>
        </div>
    <?php endif; ?>
        
    <a href="<?php echo e(url('foodbrand/create')); ?>" class="btn btn-success" > Registro de Marca de Alimentos</a>
    <br/>
    <br/>
    <table id= "my_table" class="table table-light">
        <thead class="thead-light">
            <tr>
                <th>Marca</th>
                <th>Cantidad/Proteina</th>
                <th>Acciones</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $foodbrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foodbrand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($foodbrand->name); ?></td>
                <td><?php echo e($foodbrand->protein); ?> %</td>
                <td>
                
                <a href="<?php echo e(url('/foodbrand/'.$foodbrand->id.'/edit')); ?>" class="btn btn-warning">
                    Editar
                </a>
                
                    
                <form action="<?php echo e(url('/foodbrand/'.$foodbrand->id )); ?>" class="d-inline" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('DELETE')); ?>

                    <input class="btn btn-danger" type="submit" onclick="return confirm('¿Quieres borrar?')" 
                    value="Borrar">

                </form>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
    <script>
        $(document).ready( function () {
            $('#my_table').DataTable();
        } );
    </script>  
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asopistar\resources\views/foodbrand/index.blade.php ENDPATH**/ ?>