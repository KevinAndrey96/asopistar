

<?php $__env->startSection('content'); ?>
<div class="container">
    
    <?php if(Session::has('mensaje')): ?>
        <div class="alert alert-warning alert-dismissible" role="alert">
            <?php echo e(Session::get('mensaje')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close" ></button>
        </div>
    <?php endif; ?>

    <?php if(Auth::user()->rol == 'administrador'): ?> 
    <h1>Pesajes</h1>
    <?php endif; ?>
    <?php if(Auth::user()->rol == 'piscicultor'): ?>     
    <a href="<?php echo e(url('weight/create/'.$pond_id)); ?>" class="btn btn-success" > Registrar Pesaje</a>
    <?php endif; ?>
    <br/>
    <br/>
    <table id= "my_table" class="table table-light">
        <thead class="thead-light">
            <tr>
                <th>Piscicultor</th>
                <th># de Estanque</th>
                <th>Muestreo</th>
                <th>Peso Total</th>
                <th># de Peces</th>
                <th>Peso Prom</th>
                <?php if(Auth::user()->rol == 'piscicultor'): ?> 
                <th>Acciones</th>
                <?php endif; ?>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $weights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($weight->user->name); ?>

                </td>
                <td>
                    <?php echo e($weight->pond->pond_code); ?>

                </td>
                <td><?php echo e($weight->agent); ?></td>
                <td><?php echo e($weight->total_weight); ?> kg</td>
                <td><?php echo e($weight->fish_number); ?></td>
                <td><?php echo e($weight->average_weight); ?> gr</td>
                
                <?php if(Auth::user()->rol == 'piscicultor'): ?> 
                <td>
                
                <a href="<?php echo e(url('/weight/'.$weight->id.'/edit')); ?>" class="btn btn-warning">
                    Editar
                </a>
                
                    
                <form action="<?php echo e(url('/weight/'.$weight->id )); ?>" class="d-inline" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('DELETE')); ?>

                    <input class="btn btn-danger" type="submit" onclick="return confirm('¿Quieres borrar?')" 
                    value="Borrar">

                </form>

                </td>
                <?php endif; ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
    <script>
        $(document).ready( function () {
            $('#my_table').DataTable();
        } );
    </script> 
    <?php if(Auth::user()->rol == 'administrador'): ?> 
    <a class="btn btn-primary" href="<?php echo e(url('/user/'.$id )); ?>"> Regresar</a>
    <?php endif; ?>
    <?php if(Auth::user()->rol == 'piscicultor'): ?>
    <a class="btn btn-primary" href="<?php echo e(url('/pond')); ?>"> Regresar</a>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asopistar\resources\views/weight/index.blade.php ENDPATH**/ ?>